/*
 * Welcome to your app's main JavaScript file!
 *
 */
import '../css/black.scss';
